package com.tvtidy.phone;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.graphics.Color;import android.view.*;import android.widget.*;import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;
public class PhoneActivity extends Activity{
 EditText host; TextView status; Uri picked; static final int PICK=42; int bg=0xff10111b,panel=0xff1d2030,white=0xfff5f3ff,purple=0xffb8a5ff;
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg); LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,30,24,24);root.setBackgroundColor(bg);setContentView(root);
 TextView brand=new TextView(this);brand.setText("TV TIDY");brand.setTextColor(white);brand.setTextSize(30);brand.setTypeface(null,1);root.addView(brand);
 TextView sub=new TextView(this);sub.setText("Пульт управления фоном");sub.setTextColor(0xffc9c5dc);sub.setTextSize(16);sub.setPadding(0,4,0,26);root.addView(sub);
 TextView label=new TextView(this);label.setText("АДРЕС ТЕЛЕВИЗОРА");label.setTextColor(0xffc9c5dc);label.setTextSize(12);root.addView(label);
 host=new EditText(this);host.setSingleLine(true);host.setText("http://192.168.1.140:8765");host.setHint("http://IP-телевизора:8765");host.setTextColor(white);host.setHintTextColor(0xff77798d);host.setPadding(14,12,14,12);host.setBackgroundColor(panel);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=8;hp.bottomMargin=20;root.addView(host,hp);
 Button choose=new Button(this);choose.setText("Выбрать фон из галереи");root.addView(choose);choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);});
 Button send=new Button(this);send.setText("Передать фон на телевизор");root.addView(send);send.setOnClickListener(v->{if(picked==null){Toast.makeText(this,"Сначала выберите фотографию",Toast.LENGTH_SHORT).show();return;}upload();});
 status=new TextView(this);status.setText("Телефон и телевизор должны быть в одной Wi‑Fi сети.");status.setTextColor(0xffc9c5dc);status.setTextSize(14);status.setPadding(0,20,0,0);root.addView(status);
 TextView foot=new TextView(this);foot.setText("Локальная передача • без облака");foot.setTextColor(0xff77798d);foot.setPadding(0,28,0,0);root.addView(foot);
 }
 protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK&&res==RESULT_OK&&data!=null){picked=data.getData();status.setText("Фото выбрано. Нажмите «Передать фон на телевизор».");}}
 void upload(){status.setText("Передача…");new Thread(()->{HttpURLConnection c=null;try{
 String url=host.getText().toString().trim();if(!url.startsWith("http://")&&!url.startsWith("https://"))url="http://"+url;
 String boundary="----TVTidy"+System.currentTimeMillis();c=(HttpURLConnection)new URL(url+"/upload").openConnection();c.setConnectTimeout(8000);c.setReadTimeout(20000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
 try(OutputStream out=c.getOutputStream();InputStream in=getContentResolver().openInputStream(picked)){out.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"wallpaper.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.ISO_8859_1));}
 int code=c.getResponseCode();runOnUiThread(()->status.setText(code>=200&&code<300?"Фон передан! Если экран не обновился, перезапустите TV Tidy.":"Ошибка передачи: HTTP "+code));
 }catch(Exception e){runOnUiThread(()->status.setText("Не удалось подключиться. Проверьте IP, порт 8765 и одну Wi‑Fi сеть."));}finally{if(c!=null)c.disconnect();}}).start();}
}
