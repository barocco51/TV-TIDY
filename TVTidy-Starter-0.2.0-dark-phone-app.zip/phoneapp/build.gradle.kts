plugins { id("com.android.application") }
android {
 namespace = "com.tvtidy.phone"
 compileSdk = 35
 defaultConfig { applicationId = "com.tvtidy.phone"; minSdk = 23; targetSdk = 28; versionCode = 1; versionName = "0.1.0" }
}
