package com.tvtidy.controller

import android.os.Bundle
import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.net.InetSocketAddress
import java.net.Socket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Ink = Color(0xFF14201D)
private val Mint = Color(0xFFB8F28B)
private val Canvas = Color(0xFFF5F7F3)
private val Muted = Color(0xFF64716A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Ink,
                    onPrimary = Color.White,
                    secondary = Color(0xFF3B6B54),
                    background = Canvas,
                    surface = Color.White
                )
            ) {
                TVTidyApp()
            }
        }
    }
}

private enum class Screen(val title: String) {
    HOME("TV Tidy"),
    CONNECT("Подключение ТВ"),
    ANALYSE("Анализ телевизора"),
    RESTORE("Резервная копия"),
    ACTIVITY("Управление и журнал"),
    SETTINGS("Настройки")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TVTidyApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(screen.title, fontWeight = FontWeight.Bold)
                        if (screen == Screen.HOME) {
                            Text("Порядок на ТВ — с возможностью восстановления", style = MaterialTheme.typography.labelMedium, color = Muted)
                        }
                    }
                }
            )
        },
        containerColor = Canvas
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    onConnect = { screen = Screen.CONNECT },
                    onAnalyse = { screen = Screen.ANALYSE },
                    onRestore = { screen = Screen.RESTORE },
                    onActivity = { screen = Screen.ACTIVITY },
                    onSettings = { screen = Screen.SETTINGS }
                )
                Screen.CONNECT -> ConnectScreen(onBack = { screen = Screen.HOME })
                Screen.ANALYSE -> AnalysisScreen(onBack = { screen = Screen.HOME })
                Screen.RESTORE -> RestoreScreen(onBack = { screen = Screen.HOME })
                Screen.ACTIVITY -> ActivityScreen(onBack = { screen = Screen.HOME })
                Screen.SETTINGS -> SettingsScreen(onBack = { screen = Screen.HOME })
            }
        }
    }
}

@Composable
private fun HomeScreen(
    onConnect: () -> Unit,
    onAnalyse: () -> Unit,
    onRestore: () -> Unit,
    onActivity: () -> Unit,
    onSettings: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Ink),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(54.dp).background(Mint, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = Ink, modifier = Modifier.size(28.dp))
            }
            Text("Твой телевизор. Твои правила.", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                "Сначала проверь Android TV. Все действия должны быть понятными, обратимыми и выполняться только с твоего согласия.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFFD5DED8)
            )
            Button(onClick = onConnect, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Devices, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Подключить телевизор")
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ArrowForward, contentDescription = null)
            }
        }
    }

    SectionLabel("ВОЗМОЖНОСТИ")
    ActionCard("Анализ устройства", "Понятные названия, поиск и предварительная оценка риска для полученных пакетов.", Icons.Default.Security, onAnalyse)
    ActionCard("Резервное копирование", "Профиль подключения и план восстановления.", Icons.Default.Restore, onRestore)
    ActionCard("Удалённое управление", "Диагностика сетевого ADB; команды станут доступны после авторизации.", Icons.Default.Devices, onActivity)
    ActionCard("Очистка и лаунчер", "Запланированные функции. Системные приложения не изменяются автоматически.", Icons.Default.Tune, onSettings)

    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE9F4E2))) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF2F6844))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Безопасный ознакомительный режим", fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "TV Tidy использует авторизованный ADB для чтения списка пакетов. Анализ пока только читает данные и не меняет настройки телевизора.",
                    color = Color(0xFF3D5A47),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun ConnectScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tv_tidy_profile", Context.MODE_PRIVATE) }
    var host by remember { mutableStateOf(prefs.getString("host", "192.168.1.140") ?: "192.168.1.140") }
    var port by remember { mutableStateOf(prefs.getString("port", "5555") ?: "5555") }
    var status by remember { mutableStateOf("Профиль загружен. Нажми «Проверить ADB» для обмена с демоном телевизора.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    PageIntro("Подключение к телевизору", "Укажи локальный IP-адрес ТВ и TCP-порт ADB. Телефон и телевизор должны быть в одной доверенной сети Wi-Fi.")
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Сетевой адрес телевизора", fontWeight = FontWeight.Bold, color = Ink)
            androidx.compose.material3.OutlinedTextField(
                value = host,
                onValueChange = { host = it.trim() },
                label = { Text("IP-адрес или имя узла ТВ") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
            )
            androidx.compose.material3.OutlinedTextField(
                value = port,
                onValueChange = { port = it.filter(Char::isDigit).take(5) },
                label = { Text("TCP-порт") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedButton(
                onClick = {
                    val targetHost = host.trim()
                    val targetPort = port.toIntOrNull()
                    if (targetHost.isBlank() || targetPort == null || targetPort !in 1..65535) {
                        status = "Укажи корректный адрес и порт (1–65535)."
                    } else {
                        prefs.edit().putString("host", targetHost).putString("port", targetPort.toString()).apply()
                        status = "Профиль телевизора сохранён на телефоне."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Сохранить профиль ТВ") }
            Button(
                onClick = {
                    val targetHost = host.trim()
                    val targetPort = port.toIntOrNull()
                    if (targetHost.isBlank() || targetPort == null || targetPort !in 1..65535) {
                        status = "Укажи корректный адрес и порт (1–65535)."
                    } else {
                        busy = true
                        status = "Выполняем начальный обмен ADB…"
                        prefs.edit().putString("host", targetHost).putString("port", targetPort.toString()).apply()
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                try {
                                    when (val result = AdbClient.connectAndListPackages(targetHost, targetPort)) {
                                        is AdbClient.Result.Connected -> {
                                            prefs.edit()
                                                .putStringSet("last_packages", result.packages.toSet())
                                                .putString("last_adb_banner", result.banner)
                                                .putLong("last_scan_time", System.currentTimeMillis())
                                                .apply()
                                            "Авторизация ADB успешна. Получено пакетов: ${result.packages.size}. Открой «Анализ телевизора», чтобы посмотреть список."
                                        }
                                        AdbClient.Result.AuthorizationTimedOut -> "Ожидание подтверждения на телевизоре завершилось. Повтори подключение и нажми «Разрешить» на экране ТВ."
                                        AdbClient.Result.AuthorizationRejected -> "Телевизор не принял ключ TV Tidy. Проверь запрос на экране ТВ и повтори подключение."
                                        AdbClient.Result.SecureTransportUnsupported -> "Телевизор запросил защищённый транспорт ADB, который пока не поддержан этой версией."
                                        is AdbClient.Result.Failed -> "ADB не завершил подключение: ${result.message}."
                                    }
                                } catch (e: java.net.ConnectException) {
                                    "Соединение отклонено: ADB не слушает этот порт. Проверь сетевую отладку и порт на ТВ."
                                } catch (e: java.net.SocketTimeoutException) {
                                    "Время ожидания истекло. Если на ТВ появилось окно разрешения, нажми «Разрешить» и попробуй снова."
                                } catch (e: Exception) {
                                    "Не удалось подключиться к ADB: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                }
                            }
                            status = result
                            busy = false
                        }
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Подключаемся…" else "Проверить ADB") }
            Text(status, color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
    }
    InfoCard("Что происходит при подключении", listOf(
        "TV Tidy создаёт собственный RSA-ключ в защищённом хранилище Android; закрытый ключ не экспортируется.",
        "Если ТВ покажет запрос авторизации, нажми «Разрешить» и при желании включи «Всегда разрешать».",
        "После авторизации приложение запрашивает только список пакетов. Оно не отключает и не удаляет приложения.",
        "Не открывай ADB в публичный интернет. Используй доверенную домашнюю сеть и отключай отладку после завершения."
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

private enum class PackageRisk(val title: String) {
    CRITICAL("Высокий риск — не отключать"),
    SYSTEM("Системный — нужна проверка"),
    REVIEW("Неизвестный — изучить вручную")
}

private data class PackageInfoTidy(
    val packageName: String,
    val displayName: String,
    val risk: PackageRisk,
    val reason: String
)

/** Conservative, name-only hints. This is not a guarantee that a package is safe to disable. */
private fun classifyPackage(packageName: String): PackageInfoTidy {
    val p = packageName.lowercase(Locale.ROOT)
    val criticalTokens = listOf(
        "systemui", "settings", "packageinstaller", "permissioncontroller",
        "shell", "inputmethod", "keyguard", "launcher", "wifi", "bluetooth",
        "networkstack", "connectivity", "telephony", "provision", "adb", "media.providers"
    )
    val knownNames = listOf(
        "com.google.android.youtube.tv" to "YouTube для ТВ",
        "com.google.android.youtube" to "YouTube",
        "com.netflix.ninja" to "Netflix",
        "com.amazon.amazonvideo.livingroom" to "Prime Video",
        "com.disney.disneyplus" to "Disney+",
        "com.google.android.videos" to "Google TV / Фильмы",
        "com.google.android.play.games" to "Google Play Игры",
        "com.android.vending" to "Google Play Маркет",
        "com.google.android.gms" to "Сервисы Google Play",
        "com.google.android.gsf" to "Google Services Framework",
        "com.google.android.tvlauncher" to "Главный экран Android TV",
        "com.google.android.apps.tv.launcherx" to "Главный экран Google TV",
        "com.android.tv.settings" to "Настройки Android TV",
        "com.android.systemui" to "Системный интерфейс Android",
        "com.android.packageinstaller" to "Установщик приложений",
        "com.google.android.permissioncontroller" to "Управление разрешениями",
        "com.google.android.inputmethod.latin" to "Клавиатура Gboard",
        "com.google.android.tvrecommendations" to "Рекомендации Android TV",
        "com.google.android.backuptransport" to "Резервное копирование Android",
        "com.google.android.cast" to "Chromecast / трансляция"
    )
    val friendly = knownNames.firstOrNull { p == it.first }?.second ?: guessFriendlyName(packageName)
    val risk = when {
        criticalTokens.any { token -> p.contains(token) } -> PackageRisk.CRITICAL
        p.startsWith("com.android.") || p.startsWith("com.google.android.") ||
            p.startsWith("com.google.") || p.startsWith("com.droidlogic.") ||
            p.startsWith("com.mediatek.") || p.startsWith("com.amlogic.") ||
            p.startsWith("com.iflytek.") || p.startsWith("com.iflix.") -> PackageRisk.SYSTEM
        else -> PackageRisk.REVIEW
    }
    val reason = when (risk) {
        PackageRisk.CRITICAL -> "Название указывает на компонент, который может влиять на запуск, настройки, сеть, ввод или безопасность ТВ. Не отключай его."
        PackageRisk.SYSTEM -> "Похоже на системный пакет или компонент платформы. По одному имени нельзя определить, можно ли его отключить."
        PackageRisk.REVIEW -> "Пакет не распознан по встроенному справочнику. Проверь назначение и зависимости перед любыми изменениями."
    }
    return PackageInfoTidy(packageName, friendly, risk, reason)
}

private fun guessFriendlyName(packageName: String): String {
    val leaf = packageName.substringAfterLast('.')
        .replace(Regex("([a-z])([A-Z])"), "\$1 \$2")
        .replace('_', ' ').replace('-', ' ')
    return leaf.split(Regex("\\s+")).filter { it.isNotBlank() }
        .joinToString(" ") { it.replaceFirstChar { ch -> ch.uppercase() } }
        .ifBlank { packageName }
}

@Composable
private fun AnalysisScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tv_tidy_profile", Context.MODE_PRIVATE) }
    val packages = remember { prefs.getStringSet("last_packages", emptySet())?.toList()?.sorted().orEmpty() }
    val lastScan = prefs.getLong("last_scan_time", 0L)
    var query by remember { mutableStateOf("") }
    var selectedRisk by remember { mutableStateOf<PackageRisk?>(null) }
    val analyzed = remember(packages) { packages.map(::classifyPackage) }
    val criticalCount = analyzed.count { it.risk == PackageRisk.CRITICAL }
    val systemCount = analyzed.count { it.risk == PackageRisk.SYSTEM }
    val reviewCount = analyzed.count { it.risk == PackageRisk.REVIEW }
    val filtered = analyzed.filter { item ->
        (selectedRisk == null || item.risk == selectedRisk) &&
            (query.isBlank() || item.packageName.contains(query.trim(), ignoreCase = true) ||
                item.displayName.contains(query.trim(), ignoreCase = true))
    }

    PageIntro("Анализ телевизора", "TV Tidy классифицирует пакеты по имени и показывает ориентировочный риск. Это предварительная подсказка, а не подтверждение безопасности.")
    InfoCard("Результат сканирования", listOf(
        "Устройство: iFFALCON / Android TV 11 (по предоставленным данным)",
        "Всего пакетов: ${packages.size}",
        if (lastScan > 0L) "Последнее чтение: ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(lastScan))}" else "Последнее чтение: ещё не выполнялось",
        "Режим: только чтение — изменения не применяются"
    ))
    if (packages.isNotEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            RiskSummaryCard("Не отключать", criticalCount, Color(0xFFFFE7E3), Modifier.weight(1f))
            RiskSummaryCard("Системные", systemCount, Color(0xFFFFF1D9), Modifier.weight(1f))
            RiskSummaryCard("Проверить", reviewCount, Color(0xFFE8F1FF), Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Поиск по приложениям", fontWeight = FontWeight.Bold, color = Ink)
                androidx.compose.material3.OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Название или имя пакета") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Фильтр по оценке", fontWeight = FontWeight.SemiBold, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { selectedRisk = null }, modifier = Modifier.weight(1f)) { Text("Все") }
                    OutlinedButton(onClick = { selectedRisk = PackageRisk.CRITICAL }, modifier = Modifier.weight(1f)) { Text("Высокий") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { selectedRisk = PackageRisk.SYSTEM }, modifier = Modifier.weight(1f)) { Text("Системные") }
                    OutlinedButton(onClick = { selectedRisk = PackageRisk.REVIEW }, modifier = Modifier.weight(1f)) { Text("Проверить") }
                }
                Text("Показано: ${filtered.size} из ${packages.size}", color = Muted, style = MaterialTheme.typography.labelMedium)
            }
        }
        filtered.take(300).forEach { item ->
            val tint = when (item.risk) {
                PackageRisk.CRITICAL -> Color(0xFFFFE7E3)
                PackageRisk.SYSTEM -> Color(0xFFFFF1D9)
                PackageRisk.REVIEW -> Color(0xFFE8F1FF)
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(item.displayName, fontWeight = FontWeight.Bold, color = Ink)
                    Text(item.packageName, color = Muted, style = MaterialTheme.typography.bodySmall)
                    Surface(color = tint, shape = RoundedCornerShape(8.dp)) {
                        Text(item.risk.title, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp), color = Ink, style = MaterialTheme.typography.labelMedium)
                    }
                    Text(item.reason, color = Ink, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (filtered.size > 300) Text("Показаны первые 300 результатов. Уточни поиск, чтобы найти остальные.", color = Muted)
    } else {
        InfoCard("Пока нет данных", listOf("Перейди в «Подключение к телевизору» и выполни авторизованное подключение ADB."))
    }
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1D9))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Важно: это оценка, не белый список", fontWeight = FontWeight.Bold, color = Ink)
            Text("Оценка основана только на имени пакета. Она не проверяет, какие функции зависят от него. Пока TV Tidy ничего не отключает и не удаляет. Перед реализацией управления добавим сведения о системном/пользовательском пакете и план восстановления.", color = Ink)
        }
    }
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun RiskSummaryCard(title: String, count: Int, tint: Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = tint), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(count.toString(), fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.titleLarge)
            Text(title, color = Ink, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun RestoreScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tv_tidy_profile", Context.MODE_PRIVATE) }
    var message by remember { mutableStateOf("В этой сессии профиль ещё не экспортировался.") }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri == null) {
            message = "Экспорт отменён."
        } else {
            try {
                val json = JSONObject().apply {
                    put("schema", 1)
                    put("app", "TV Tidy")
                    put("appVersion", "0.6.0-alpha")
                    put("tvHost", prefs.getString("host", "192.168.1.140"))
                    put("adbPort", prefs.getString("port", "5555"))
                    put("tvModel", "iFFALCON AR2101")
                    put("androidVersion", "11")
                    put("backupType", "connection-profile-only")
                    put("createdAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date()))
                }
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(json.toString(2).toByteArray(Charsets.UTF_8))
                } ?: throw IllegalStateException("Не удалось открыть выбранный файл")
                message = "Профиль подключения экспортирован. Это не резервная копия приложений или состояния ТВ."
            } catch (e: Exception) {
                message = "Ошибка экспорта: ${e.localizedMessage ?: e.javaClass.simpleName}"
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) {
            message = "Импорт отменён."
        } else {
            try {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException("Не удалось прочитать выбранный файл")
                val json = JSONObject(raw)
                require(json.optInt("schema", -1) == 1) { "Неподдерживаемый формат профиля" }
                val importedHost = json.optString("tvHost", "").trim()
                val importedPort = json.optString("adbPort", "5555").trim()
                require(importedHost.isNotBlank()) { "В профиле не указан адрес телевизора" }
                val importedPortNumber = importedPort.toIntOrNull()
                require(importedPortNumber != null && importedPortNumber in 1..65535) { "В профиле указан неверный порт" }
                prefs.edit().putString("host", importedHost).putString("port", importedPort).apply()
                message = "Профиль импортирован. Открой «Подключение ТВ» и проверь адрес перед тестированием."
            } catch (e: Exception) {
                message = "Ошибка импорта: ${e.localizedMessage ?: e.javaClass.simpleName}"
            }
        }
    }

    PageIntro("Резервная копия и восстановление", "Сейчас можно экспортировать и импортировать профиль подключения. Для резервной копии состояния телевизора требуется авторизованный ADB, который пока не реализован.")
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Локальный профиль подключения", fontWeight = FontWeight.Bold, color = Ink)
            Text("Телевизор: ${prefs.getString("host", "192.168.1.140")}  ·  Порт: ${prefs.getString("port", "5555")}", color = Muted)
            Button(onClick = { exportLauncher.launch("tv-tidy-profile.json") }, modifier = Modifier.fillMaxWidth()) {
                Text("Экспортировать профиль в файл")
            }
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) {
                Text("Импортировать профиль из файла")
            }
            Text(message, color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
    }
    InfoCard("Что не входит в эту резервную копию", listOf(
        "Список установленных пакетов телевизора",
        "Состояние системных приложений (включены или отключены)",
        "APK-файлы приложений или системные разделы",
        "План отмены изменений на телевизоре"
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun ActivityScreen(onBack: () -> Unit) {
    PageIntro("Удалённое управление и журнал", "Команды дистанционного управления пока не включены. Здесь показаны доступные функции безопасного режима.")
    InfoCard("Доступно сейчас", listOf("Проверка TCP-подключения", "Сохранение локального профиля ТВ", "Экспорт и импорт профиля подключения"))
    InfoCard("Пока недоступно", listOf("Оболочка с авторизацией ADB", "Получение списка пакетов ТВ", "События кнопок пульта", "Включение/отключение пакетов и проверенная отмена"))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit) {
    PageIntro("Настройки", "Настройки TV Tidy с приоритетом конфиденциальности.")
    InfoCard("Текущие настройки по умолчанию", listOf(
        "Учётная запись не требуется",
        "Сбор аналитики не настроен",
        "Список приложений не отправляется в облако",
        "Профиль подключения хранится локально на телефоне",
        "Системные команды не включены",
        "Экспорт содержит только профиль подключения, а не состояние системы ТВ"
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun PageIntro(title: String, description: String) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
    Text(description, style = MaterialTheme.typography.bodyLarge, color = Muted)
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = Muted, fontWeight = FontWeight.Bold)
}

@Composable
private fun ActionCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(Modifier.size(44.dp).background(Color(0xFFEAF1E7), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Ink)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.Bold, color = Ink)
                Text(description, style = MaterialTheme.typography.bodyMedium, color = Muted)
            }
            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Muted)
        }
    }
}

@Composable
private fun InfoCard(title: String, lines: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Ink)
            lines.forEach { line ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.padding(top = 7.dp).size(6.dp).background(Mint, CircleShape))
                    Text(line, color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
