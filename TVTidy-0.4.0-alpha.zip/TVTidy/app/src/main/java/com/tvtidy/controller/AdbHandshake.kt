package com.tvtidy.controller

import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Performs the first ADB protocol exchange. It intentionally does not authenticate
 * or execute commands yet; this lets the UI distinguish an ADB daemon from any TCP service. */
internal object AdbHandshake {
    private const val ADB_VERSION = 0x01000000
    private const val ADB_MAX_DATA = 4096
    private const val CMD_CNXN = 0x4e584e43 // CNXN
    private const val CMD_AUTH = 0x48545541 // AUTH
    private const val CMD_STLS = 0x534c5453 // STLS

    sealed interface Result {
        data class DaemonDetected(val banner: String) : Result
        data object AuthenticationRequired : Result
        data object SecureTransportRequested : Result
        data class NotAdb(val detail: String) : Result
    }

    fun probe(host: String, port: Int): Result {
        Socket().use { socket ->
            socket.connect(InetSocketAddress(host, port), 3500)
            socket.soTimeout = 3500
            val output = DataOutputStream(socket.getOutputStream())
            val input = DataInputStream(socket.getInputStream())
            val payload = "host::features=shell_v2,cmd,stat_v2,ls_v2\u0000".toByteArray(Charsets.UTF_8)
            writePacket(output, CMD_CNXN, ADB_VERSION, ADB_MAX_DATA, payload)
            val header = ByteArray(24)
            input.readFully(header)
            val fields = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            val command = fields.int
            val arg0 = fields.int
            fields.int // arg1
            val length = fields.int
            fields.int // checksum
            fields.int // magic
            if (length < 0 || length > 1024 * 1024) return Result.NotAdb("Некорректный заголовок протокола")
            val data = ByteArray(length)
            if (length > 0) input.readFully(data)
            return when (command) {
                CMD_AUTH -> Result.AuthenticationRequired
                CMD_CNXN -> {
                    val banner = data.toString(Charsets.UTF_8).trimEnd('\u0000')
                    Result.DaemonDetected(if (banner.isBlank()) "ADB daemon (версия $arg0)" else banner)
                }
                CMD_STLS -> Result.SecureTransportRequested
                else -> Result.NotAdb("Неожиданный ответ ADB: 0x${command.toUInt().toString(16)}")
            }
        }
    }

    private fun writePacket(out: DataOutputStream, command: Int, arg0: Int, arg1: Int, data: ByteArray) {
        val checksum = data.fold(0L) { sum, byte -> (sum + (byte.toInt() and 0xff)) and 0xffffffffL }.toInt()
        val header = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(command)
            .putInt(arg0)
            .putInt(arg1)
            .putInt(data.size)
            .putInt(checksum)
            .putInt(command.inv())
            .array()
        out.write(header)
        if (data.isNotEmpty()) out.write(data)
        out.flush()
    }
}
