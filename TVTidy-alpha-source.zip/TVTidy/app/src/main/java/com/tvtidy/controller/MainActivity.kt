package com.tvtidy.controller

import android.os.Bundle
import java.net.InetSocketAddress
import java.net.Socket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Ink = Color(0xFF14201D)
private val Mint = Color(0xFFB8F28B)
private val Canvas = Color(0xFFF5F7F3)
private val Muted = Color(0xFF64716A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Ink,
                    onPrimary = Color.White,
                    secondary = Color(0xFF3B6B54),
                    background = Canvas,
                    surface = Color.White
                )
            ) {
                TVTidyApp()
            }
        }
    }
}

private enum class Screen(val title: String) {
    HOME("TV Tidy"),
    CONNECT("Connect a TV"),
    ANALYSE("TV analysis"),
    RESTORE("Backup & restore"),
    ACTIVITY("Activity log"),
    SETTINGS("Settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TVTidyApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(screen.title, fontWeight = FontWeight.Bold)
                        if (screen == Screen.HOME) {
                            Text("A calmer TV, with a way back", style = MaterialTheme.typography.labelMedium, color = Muted)
                        }
                    }
                }
            )
        },
        containerColor = Canvas
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    onConnect = { screen = Screen.CONNECT },
                    onAnalyse = { screen = Screen.ANALYSE },
                    onRestore = { screen = Screen.RESTORE },
                    onActivity = { screen = Screen.ACTIVITY },
                    onSettings = { screen = Screen.SETTINGS }
                )
                Screen.CONNECT -> ConnectScreen(onBack = { screen = Screen.HOME })
                Screen.ANALYSE -> AnalysisScreen(onBack = { screen = Screen.HOME })
                Screen.RESTORE -> RestoreScreen(onBack = { screen = Screen.HOME })
                Screen.ACTIVITY -> ActivityScreen(onBack = { screen = Screen.HOME })
                Screen.SETTINGS -> SettingsScreen(onBack = { screen = Screen.HOME })
            }
        }
    }
}

@Composable
private fun HomeScreen(
    onConnect: () -> Unit,
    onAnalyse: () -> Unit,
    onRestore: () -> Unit,
    onActivity: () -> Unit,
    onSettings: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Ink),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(54.dp).background(Mint, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = Ink, modifier = Modifier.size(28.dp))
            }
            Text("Your TV. Your rules.", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                "Inspect your Android TV before changing anything. Every action should be visible, reversible, and yours to approve.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFFD5DED8)
            )
            Button(onClick = onConnect, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Devices, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Connect a TV")
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ArrowForward, contentDescription = null)
            }
        }
    }

    SectionLabel("WORKSPACE")
    ActionCard("Analyse device", "Package inventory and safety review — ADB integration pending.", Icons.Default.Security, onAnalyse)
    ActionCard("Backup & restore", "Review local restore-point status and recovery plan.", Icons.Default.Restore, onRestore)
    ActionCard("Remote control", "Connection diagnostics first; remote commands are not enabled yet.", Icons.Default.Devices, onActivity)
    ActionCard("Cleanup & launcher", "Planned modules. No system app will be changed automatically.", Icons.Default.Tune, onSettings)

    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE9F4E2))) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF2F6844))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Safe preview mode", fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "This alpha can test whether the TV debugging port is reachable. It does not authenticate ADB or change the TV yet.",
                    color = Color(0xFF3D5A47),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun ConnectScreen(onBack: () -> Unit) {
    var host by remember { mutableStateOf("192.168.1.140") }
    var port by remember { mutableStateOf("5555") }
    var status by remember { mutableStateOf("Not checked yet") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    PageIntro("Connect securely", "Enter the TV's local IP address and ADB TCP port. Phone and TV must be on the same trusted Wi-Fi.")
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("TV network address", fontWeight = FontWeight.Bold, color = Ink)
            androidx.compose.material3.OutlinedTextField(
                value = host,
                onValueChange = { host = it.trim() },
                label = { Text("TV IP address or host") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
            )
            androidx.compose.material3.OutlinedTextField(
                value = port,
                onValueChange = { port = it.filter(Char::isDigit).take(5) },
                label = { Text("TCP port") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Button(
                onClick = {
                    val targetHost = host.trim()
                    val targetPort = port.toIntOrNull()
                    if (targetHost.isBlank() || targetPort == null || targetPort !in 1..65535) {
                        status = "Enter a valid host and port (1–65535)."
                    } else {
                        busy = true
                        status = "Checking TCP port…"
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                try {
                                    Socket().use { socket ->
                                        socket.connect(InetSocketAddress(targetHost, targetPort), 2500)
                                    }
                                    "Port is reachable. This does not yet confirm ADB authentication."
                                } catch (e: Exception) {
                                    when (e) {
                                        is java.net.ConnectException -> "Connection refused: no service is listening on this port."
                                        is java.net.SocketTimeoutException -> "Timed out. Check Wi-Fi, IP address, port, or router isolation."
                                        else -> "Could not connect: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                    }
                                }
                            }
                            status = result
                            busy = false
                        }
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Checking…" else "Test connection") }
            Text(status, color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
    }
    InfoCard("What this test means", listOf(
        "A successful result only proves that a TCP service accepts connections.",
        "ADB device discovery, RSA authorization, and shell commands are not implemented in this alpha.",
        "Do not expose ADB to the public internet. Use a trusted home network and disable debugging when finished."
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back to dashboard") }
}

@Composable
private fun AnalysisScreen(onBack: () -> Unit) {
    PageIntro("TV analysis", "Live package inventory is not available until authenticated ADB transport is added. This page intentionally does not invent device data.")
    InfoCard("Example analysis", listOf(
        "Target: iFFALCON / Android TV 11 (user-provided details)",
        "Installed packages: not read from TV",
        "Proposed changes: none",
        "System component safety: not evaluated"
    ))
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1D9))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("No changes will be applied", fontWeight = FontWeight.Bold)
            Text("TV Tidy must show the exact proposed operations and create a restore point before any future system modification.")
        }
    }
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back to dashboard") }
}

@Composable
private fun RestoreScreen(onBack: () -> Unit) {
    PageIntro("Backup & restore", "A restore point must be created from the actual package state before any changes are allowed.")
    InfoCard("Current status", listOf(
        "No TV connected",
        "No restore point exists",
        "Backup export, device-side package state capture, and undo are not implemented yet"
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back to dashboard") }
}

@Composable
private fun ActivityScreen(onBack: () -> Unit) {
    PageIntro("Remote control & activity", "This alpha does not send remote-control commands. Connection tests can be added to the activity log in a later build.")
    InfoCard("Recent activity", listOf("Project opened", "No TV operations have been run"))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back to dashboard") }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit) {
    PageIntro("Settings", "Privacy-first defaults for the TV Tidy project.")
    InfoCard("Current defaults", listOf(
        "No account required",
        "No analytics configured",
        "No cloud upload of device inventory",
        "No system commands enabled"
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back to dashboard") }
}

@Composable
private fun PageIntro(title: String, description: String) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
    Text(description, style = MaterialTheme.typography.bodyLarge, color = Muted)
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = Muted, fontWeight = FontWeight.Bold)
}

@Composable
private fun ActionCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(Modifier.size(44.dp).background(Color(0xFFEAF1E7), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Ink)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.Bold, color = Ink)
                Text(description, style = MaterialTheme.typography.bodyMedium, color = Muted)
            }
            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Muted)
        }
    }
}

@Composable
private fun InfoCard(title: String, lines: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Ink)
            lines.forEach { line ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.padding(top = 7.dp).size(6.dp).background(Mint, CircleShape))
                    Text(line, color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
