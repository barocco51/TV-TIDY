# TV Tidy — Android companion alpha

TV Tidy is a branded Android companion app for managing an Android TV / Google TV on a trusted local network.

## Existing input files checked

- Original reference APK supplied in this workspace: `cleanyourtv-0.3.3.apk` (4,904,471 bytes).
- Existing project retained at `TVTidy/`; this is an update to that project, not a new duplicate.
- The reference APK contains `assets/bundled/cleanyourtv-launcher.apk`, `assets/bundled/cleanyourtv-curtain.apk`, and a signed module catalogue. Those bundled components have **not** been copied into TV Tidy because their compatibility, individual licensing, and install/restore behavior must be reviewed first.

## What this alpha does

- Shows the TV Tidy dashboard and workflow screens.
- Lets the user enter a TV IP/hostname and TCP port (defaults to `192.168.1.140:5555`) and test whether that port accepts a TCP connection.
- Explains the result honestly: a reachable TCP port does **not** prove ADB authentication or authorize shell operations.
- Contains no destructive TV operations, no package disable/uninstall commands, and no fabricated inventory.

## Not implemented yet

- Authenticated ADB transport and RSA key management.
- Live device properties and installed-package inventory.
- Safe, reversible disable/enable operations and device-specific allow/deny lists.
- Restore-point export/import and undo.
- Remote control commands, cache cleanup, or TV launcher installation.

These require ADB transport, model-specific testing on the iFFALCON Android TV 11, and a reviewed rollback strategy. The first implementation must never automatically disable system packages or uninstall apps.

## Build the APK using only a phone

This repository includes `.github/workflows/android-apk.yml`. You can use GitHub in your phone's browser:

1. Create a GitHub repository and upload the contents of this folder (keep the `.github/workflows/android-apk.yml` file).
2. Open the repository's **Actions** tab and select **Build TV Tidy APK**.
3. Tap **Run workflow** (or push/commit a change to `main`/`master`).
4. When the workflow finishes, open the run and download the `TV-Tidy-debug-APK` artifact. GitHub may download it as a ZIP; extract it on the phone to get `app-debug.apk`.
5. Install the APK and allow installation from that browser/file manager if Android asks.

This workflow builds a **debug APK** for testing, not a Play Store release. A release build should use a private signing key and a reproducible release process.

## Local build

Requires JDK 17, Android SDK Platform 35, and Gradle 8.9. Run `gradle :app:assembleDebug` from the project root.

## Safety and privacy

- Only connect to a TV you own or are authorized to manage.
- Keep debugging on a trusted private Wi-Fi network; never expose ADB to the public internet.
- Every future mutation must show the exact package/command, capture the original state, ask for explicit confirmation, and provide a verified rollback path.
- Do not log ADB private keys, pairing codes, or unnecessary device identifiers.

## Licensing

TV Tidy is a separate implementation. The CleanYourTV APK is used as a reference for compatibility investigation, not redistributed as part of this project. Before reusing any original source, module, package list, or asset, preserve the relevant license notices and check the license for each component. The original APK contains a Bouncy Castle MIT license notice for that library; that notice alone does not establish the license of every bundled module.
