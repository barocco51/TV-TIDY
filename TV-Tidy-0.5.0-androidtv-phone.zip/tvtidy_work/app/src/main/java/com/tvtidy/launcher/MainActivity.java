package com.tvtidy.launcher;
import android.app.*; import android.provider.Settings; import org.json.*; import android.os.*; import android.graphics.*; import android.view.*; import android.widget.*; import android.content.*; import java.io.*; import java.net.*; import java.nio.charset.StandardCharsets; import java.util.*;
public class MainActivity extends Activity {
 LinearLayout root; TextView info; ServerSocket server; volatile boolean running=true; File bg;
 public void onCreate(Bundle b){super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512); bg=new File(getFilesDir(),"wallpaper.jpg"); draw(); new Thread(()->serve()).start();}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);draw();}
 void draw(){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(44,28,44,24);root.setGravity(Gravity.CENTER_VERTICAL);applyWallpaper();setContentView(root);
 TextView title=new TextView(this);title.setText("TV TIDY");title.setTextColor(-1);title.setTextSize(30);title.setTypeface(null,1);root.addView(title);
 TextView sub=new TextView(this);sub.setText("Ваш домашний экран");sub.setTextColor(0xffded9f0);sub.setTextSize(17);root.addView(sub);
 TextView head=new TextView(this);head.setText("ИЗБРАННОЕ");head.setTextColor(-1);head.setPadding(0,22,0,8);root.addView(head);
 LinearLayout row=new LinearLayout(this);root.addView(row); row.setOrientation(LinearLayout.HORIZONTAL); renderTiles(row);
 Button help=new Button(this);help.setText("Изменить фон со смартфона");root.addView(help);help.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Передача фона").setMessage("Подключите телефон к той же Wi‑Fi сети и откройте в браузере:\nhttp://"+ip()+":8765\nВыберите фото и нажмите «Передать фон».").setPositiveButton("OK",null).show());
 Button launcher=new Button(this);launcher.setText("Управление лаунчером");root.addView(launcher);launcher.setOnClickListener(v->showLauncherOptions());
 info=new TextView(this);info.setTextColor(0xffded9f0);info.setTextSize(14);info.setPadding(0,14,0,0);info.setText("Передача по Wi‑Fi: http://"+ip()+":8765");root.addView(info);
 TextView note=new TextView(this);note.setText("CleanYourTV остаётся установленным как запасной вариант.");note.setTextColor(0xffaaaabd);note.setPadding(0,14,0,0);root.addView(note);
 }
 void applyWallpaper(){
  try {
   if(bg!=null && bg.exists() && bg.length()>0){
    Bitmap bitmap=BitmapFactory.decodeFile(bg.getAbsolutePath());
    if(bitmap!=null){
     android.graphics.drawable.BitmapDrawable d=new android.graphics.drawable.BitmapDrawable(getResources(),bitmap);
     d.setGravity(Gravity.FILL);
     root.setBackground(d);
     return;
    }
   }
  } catch(Exception ignored) {}
  root.setBackgroundColor(0xff171925);
 }
 void renderTiles(LinearLayout row){
  String raw=getPreferences(0).getString("apps", "[\"ru.kinopoisk\",\"ru.tntpremier\",\"com.vk.vkvideo\"]");
  try{JSONArray a=new JSONArray(raw);int count=Math.min(a.length(),6);for(int i=0;i<count;i++){String pkg=a.getString(i);String label=appLabel(pkg);String glyph=label.length()>1?label.substring(0,2).toUpperCase():label;int[] colors={0xffffd21f,0xff7868ff,0xff2787f5,0xffe34b4b,0xff31a56b,0xff9999aa};tile(row,glyph,label,pkg,colors[i%colors.length]);}}catch(Exception e){tile(row,"К","Кинопоиск","ru.kinopoisk",0xffffd21f);tile(row,"Т","ТНТ PREMIER","ru.tntpremier",0xff7868ff);tile(row,"VK","VK Видео","com.vk.vkvideo",0xff2787f5);}
 }
 String appLabel(String pkg){if(pkg.equals("ru.kinopoisk"))return "Кинопоиск";if(pkg.equals("ru.tntpremier"))return "ТНТ PREMIER";if(pkg.equals("com.vk.vkvideo"))return "VK Видео";if(pkg.equals("com.google.android.youtube.tv"))return "YouTube";if(pkg.equals("com.google.android.videos"))return "Кино и ТВ";if(pkg.equals("com.android.tv.settings"))return "Настройки";try{android.content.pm.ApplicationInfo ai=getPackageManager().getApplicationInfo(pkg,0);return getPackageManager().getApplicationLabel(ai).toString();}catch(Exception e){return pkg;}}
 void tile(LinearLayout row,String glyph,String label,String pkg,int color){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setGravity(Gravity.CENTER);box.setFocusable(true);box.setPadding(10,14,10,14);box.setBackgroundColor(0xff292c42);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,130,1);lp.setMargins(0,0,12,0);row.addView(box,lp);TextView g=new TextView(this);g.setText(glyph);g.setTextSize(27);g.setTypeface(null,1);g.setTextColor(0xff10111b);g.setGravity(17);g.setBackgroundColor(color);box.addView(g,new LinearLayout.LayoutParams(56,56));TextView t=new TextView(this);t.setText(label);t.setTextColor(-1);t.setGravity(17);t.setTextSize(13);box.addView(t);box.setOnFocusChangeListener((v,f)->{v.setScaleX(f?1.06f:1);v.setScaleY(f?1.06f:1);v.setBackgroundColor(f?0xff494d68:0xff292c42);});box.setOnClickListener(v->{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)startActivity(i);else Toast.makeText(this,label+" не найдено на ТВ",Toast.LENGTH_LONG).show();});}

 void showLauncherOptions(){
   String message="TV Tidy не удаляет CleanYourTV.\\n\\n«Выбрать домашний экран» попробует открыть системный выбор лаунчера. Если прошивка его не поддерживает, откройте настройки ТВ → Приложения → Домашнее приложение. Не отключайте CleanYourTV, пока не проверите возврат.";
   new AlertDialog.Builder(this).setTitle("Управление лаунчером").setMessage(message)
    .setPositiveButton("Выбрать домашний экран",(d,w)->{
      try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
      catch(Exception e1){ try{startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));}
      catch(Exception e2){try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(Exception e3){Toast.makeText(this,"Откройте настройки ТВ → Приложения.",Toast.LENGTH_LONG).show();}}}
    }).setNegativeButton("Настройки ТВ",(d,w)->{try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(Exception e){}})
    .setNeutralButton("Отмена",null).show();
 }
 String ip(){try{for(NetworkInterface n:Collections.list(NetworkInterface.getNetworkInterfaces()))for(InetAddress a:Collections.list(n.getInetAddresses()))if(a instanceof Inet4Address&&!a.isLoopbackAddress()&&a.isSiteLocalAddress())return a.getHostAddress();}catch(Exception e){}return "IP-ТЕЛЕВИЗОРА";}
 void serve(){try(ServerSocket ss=new ServerSocket(8765)){server=ss;while(running){Socket s=ss.accept();new Thread(()->handle(s)).start();}}catch(Exception e){}}
 void handle(Socket s){try(Socket x=s){x.setSoTimeout(15000);InputStream in=x.getInputStream();ByteArrayOutputStream hb=new ByteArrayOutputStream();int state=0,c;while((c=in.read())!=-1){hb.write(c);if(state==0&&c==13)state=1;else if(state==1&&c==10)state=2;else if(state==2&&c==13)state=3;else if(state==3&&c==10)break;else state=0;if(hb.size()>16000)return;}String h=hb.toString("ISO-8859-1");String first=h.split("\r\n")[0];String path=first.split(" ")[1];int len=0;for(String l:h.split("\r\n"))if(l.toLowerCase().startsWith("content-length:"))len=Integer.parseInt(l.split(":")[1].trim());
 if(path.equals("/status")&&first.startsWith("GET")){reply(x,"200 OK","application/json; charset=utf-8","{\"service\":\"TV_TIDY\",\"ip\":\""+ip()+"\"}".getBytes(StandardCharsets.UTF_8));return;}
 if(first.startsWith("POST")&&len>=0&&len<20*1024*1024){byte[] body=new byte[len];int off=0;while(off<len){int n=in.read(body,off,len-off);if(n<0)break;off+=n;}
 if(path.equals("/config")){JSONObject o=new JSONObject(new String(body,StandardCharsets.UTF_8));JSONArray a=o.optJSONArray("apps");if(a==null)a=new JSONArray();getPreferences(0).edit().putString("apps",a.toString()).apply();reply(x,"200 OK","application/json","{\"ok\":true}".getBytes(StandardCharsets.UTF_8));return;}
 if(path.equals("/apply")){reply(x,"200 OK","application/json","{\"ok\":true}".getBytes(StandardCharsets.UTF_8));runOnUiThread(()->{Intent launch=new Intent(this,MainActivity.class);launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(launch);Toast.makeText(this,"Настройки TV Tidy применены",Toast.LENGTH_SHORT).show();});return;}
 if(path.equals("/home")){reply(x,"200 OK","application/json","{\"ok\":true}".getBytes(StandardCharsets.UTF_8));runOnUiThread(()->{try{startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));}catch(Exception ignored){startActivity(new Intent(Settings.ACTION_SETTINGS));}}});return;}
 if(path.equals("/upload")){String ct="";for(String l:h.split("\r\n"))if(l.toLowerCase().startsWith("content-type:"))ct=l;int bi=ct.indexOf("boundary=");if(bi<0)throw new Exception("No boundary");String boundary=ct.substring(bi+9).trim();byte[] marker=("\r\n--"+boundary).getBytes(StandardCharsets.ISO_8859_1);int p=index(body,new byte[]{13,10,13,10}),end=index(body,marker);if(p<0||end<=p)throw new Exception("Bad multipart");byte[] data=Arrays.copyOfRange(body,p+4,end);BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(data,0,data.length,o);if(o.outWidth<1)throw new Exception("Bad image");try(FileOutputStream f=new FileOutputStream(bg)){f.write(data);}reply(x,"200 OK","application/json","{\"ok\":true}".getBytes(StandardCharsets.UTF_8));runOnUiThread(()->{draw();Toast.makeText(this,"Фон обновлён",Toast.LENGTH_SHORT).show();});return;}
 }
 reply(x,"404 Not Found","text/plain","Not found".getBytes(StandardCharsets.UTF_8));
 }catch(Exception e){}}
 int index(byte[] a,byte[] b){outer:for(int i=0;i<=a.length-b.length;i++){for(int j=0;j<b.length;j++)if(a[i+j]!=b[j])continue outer;return i;}return -1;}
 void reply(Socket s,String status,String type,byte[] data)throws Exception{s.getOutputStream().write(("HTTP/1.1 "+status+"\r\nContent-Type: "+type+"\r\nContent-Length: "+data.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));s.getOutputStream().write(data);s.getOutputStream().flush();}
 public void onDestroy(){running=false;try{if(server!=null)server.close();}catch(Exception e){}super.onDestroy();}
}
