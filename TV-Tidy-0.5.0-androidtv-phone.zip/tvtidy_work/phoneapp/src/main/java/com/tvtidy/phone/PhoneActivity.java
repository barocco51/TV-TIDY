package com.tvtidy.phone;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public class PhoneActivity extends Activity {
    static final int PICK = 42, PORT = 8765;
    final int bg=0xff10111b, panel=0xff1d2030, white=0xfff5f3ff, muted=0xffc9c5dc, purple=0xffb8a5ff;
    final String[] labels={"Кинопоиск","ТНТ PREMIER","VK Видео","YouTube","Кино и ТВ","Настройки"};
    final String[] packages={"ru.kinopoisk","ru.tntpremier","com.vk.vkvideo","com.google.android.youtube.tv","com.google.android.videos","com.android.tv.settings"};
    LinearLayout root, editor; TextView status, connected; Uri picked; String tvBase=""; boolean isConnected=false; CheckBox[] appChecks;

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);getWindow().getDecorView().setSystemUiVisibility(0);showHome();}
    void base(String subtitle){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(26),dp(22),dp(22));root.setBackgroundColor(bg);ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.addView(root);setContentView(sc);TextView brand=text("TV TIDY",30,white,true);root.addView(brand);TextView sub=text(subtitle,15,muted,false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(4);sp.bottomMargin=dp(22);root.addView(sub,sp);}
    void showHome(){base("Управление Android TV");Button connect=button(isConnected?"Подключено · Настроить":"Подключить телевизор");root.addView(connect,full());connect.setOnClickListener(v->{if(isConnected)showEditor();else discover();});connected=text(isConnected?"Телевизор: "+tvBase:"Телефон автоматически найдёт TV Tidy в вашей Wi‑Fi сети.",14,muted,false);LinearLayout.LayoutParams cp=full();cp.topMargin=dp(12);root.addView(connected,cp);
      Button wallpaper=button("Изменить фон");addGap(wallpaper);wallpaper.setOnClickListener(v->{if(!isConnected){discover();return;}pickWallpaper();});
      Button arrange=button("Изменить расположение приложений");addGap(arrange);arrange.setOnClickListener(v->{if(!isConnected)discover();else showEditor();});
      Button home=button("Вернуть заводской домашний экран");addGap(home);home.setOnClickListener(v->{if(!isConnected){discover();return;}sendSimple("/home","", "Открываю настройки домашнего экрана…",false);});
      status=text("Оба устройства должны быть подключены к одной домашней Wi‑Fi сети.",13,muted,false);LinearLayout.LayoutParams st=full();st.topMargin=dp(18);root.addView(status,st);
    }
    void showEditor(){base("Настрой телевизор и нажми «Применить»");TextView cap=text("ФОН ЭКРАНА",12,muted,true);root.addView(cap);Button choose=button(picked==null?"Выбрать фото из галереи":"Фото выбрано · изменить");addGap(choose);choose.setOnClickListener(v->pickWallpaper());
      TextView apps=text("ОСНОВНЫЕ ПРИЛОЖЕНИЯ",12,muted,true);LinearLayout.LayoutParams ap=full();ap.topMargin=dp(20);root.addView(apps,ap);appChecks=new CheckBox[packages.length];for(int i=0;i<packages.length;i++){CheckBox c=new CheckBox(this);c.setText(labels[i]);c.setTextColor(white);c.setTextSize(16);c.setButtonTintList(android.content.res.ColorStateList.valueOf(purple));c.setPadding(dp(4),dp(5),dp(4),dp(5));c.setChecked(i<3);appChecks[i]=c;root.addView(c,full());}
      Button apply=button("Применить на телевизоре");LinearLayout.LayoutParams bp=full();bp.topMargin=dp(20);root.addView(apply,bp);apply.setOnClickListener(v->applySettings());Button back=button("Назад");addGap(back);back.setOnClickListener(v->showHome());status=text("Изменения появятся на телевизоре после применения.",13,muted,false);LinearLayout.LayoutParams st=full();st.topMargin=dp(12);root.addView(status,st);
    }
    void discover(){statusText("Ищу телевизор в локальной сети…");new Thread(()->{String found=findTv();runOnUiThread(()->{if(found!=null){tvBase=found;isConnected=true;showEditor();}else{isConnected=false;showHome();status.setText("TV Tidy не найден. Запусти TV Tidy на телевизоре и убедись, что оба устройства в одной Wi‑Fi сети.");}});}).start();}
    String findTv(){try{WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);if(wm==null)return null;int dhcp=wm.getDhcpInfo().ipAddress;String local=String.format(java.util.Locale.US,"%d.%d.%d.%d",dhcp&255,(dhcp>>8)&255,(dhcp>>16)&255,(dhcp>>24)&255);String prefix=local.substring(0,local.lastIndexOf('.')+1);ExecutorService pool=Executors.newFixedThreadPool(32);CompletionService<String> cs=new ExecutorCompletionService<>(pool);int count=0;for(int i=1;i<=254;i++){final String ip=prefix+i;if(ip.equals(local))continue;cs.submit(()->probe(ip));count++;}String result=null;long deadline=SystemClock.elapsedRealtime()+15000;while(SystemClock.elapsedRealtime()<deadline){Future<String> f=cs.poll(100,TimeUnit.MILLISECONDS);if(f!=null){try{String s=f.get();if(s!=null){result=s;break;}}catch(Exception ignored){}}}pool.shutdownNow();return result;}catch(Exception e){return null;}}
    String probe(String ip){try{HttpURLConnection c=(HttpURLConnection)new URL("http://"+ip+":"+PORT+"/status").openConnection();c.setConnectTimeout(250);c.setReadTimeout(250);c.setRequestMethod("GET");if(c.getResponseCode()==200){String s=read(c.getInputStream());if(s.contains("TV_TIDY"))return "http://"+ip+":"+PORT;}c.disconnect();}catch(Exception ignored){}return null;}
    void pickWallpaper(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK&&res==RESULT_OK&&data!=null){picked=data.getData();if(status!=null)status.setText("Фото выбрано. Нажми «Применить на телевизоре».");if(isConnected)showEditor();}}
    void applySettings(){if(!isConnected){discover();return;}status.setText("Применяю настройки…");new Thread(()->{try{if(picked!=null)uploadWallpaper();JSONArray arr=new JSONArray();for(int i=0;i<packages.length;i++)if(appChecks[i].isChecked())arr.put(packages[i]);JSONObject o=new JSONObject();o.put("apps",arr);postJson("/config",o.toString());postJson("/apply","{}");runOnUiThread(()->status.setText("Настройки отправлены! TV Tidy обновлён на телевизоре."));}catch(Exception e){runOnUiThread(()->status.setText("Не удалось применить настройки. Проверь подключение и запущенный TV Tidy на телевизоре."));}}).start();}
    void uploadWallpaper()throws Exception{String boundary="----TVTidy"+System.currentTimeMillis();HttpURLConnection c=(HttpURLConnection)new URL(tvBase+"/upload").openConnection();c.setConnectTimeout(5000);c.setReadTimeout(20000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);try(OutputStream out=c.getOutputStream();InputStream in=getContentResolver().openInputStream(picked)){out.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"wallpaper.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.ISO_8859_1));}int code=c.getResponseCode();c.disconnect();if(code<200||code>=300)throw new IOException("Upload HTTP "+code);}
    void postJson(String path,String json)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(tvBase+path).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(5000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream o=c.getOutputStream()){o.write(json.getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();c.disconnect();if(code<200||code>=300)throw new IOException("HTTP "+code);}
    void sendSimple(String path,String body,String message,boolean ignored){status.setText(message);new Thread(()->{try{postJson(path,body);runOnUiThread(()->status.setText("Команда отправлена на телевизор."));}catch(Exception e){runOnUiThread(()->status.setText("Не удалось отправить команду. Проверь, что TV Tidy запущен."));}}).start();}
    String read(InputStream in)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[512];int n;while((n=in.read(x))!=-1)b.write(x,0,n);return b.toString("UTF-8");}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);b.setTextColor(white);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));return b;}
    LinearLayout.LayoutParams full(){return new LinearLayout.LayoutParams(-1,-2);}void addGap(View v){LinearLayout.LayoutParams p=full();p.topMargin=dp(10);root.addView(v,p);}int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}void statusText(String s){if(status!=null)status.setText(s);else{showHome();status.setText(s);}}
}
