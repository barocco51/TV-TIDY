package com.tvtidy.controller

import android.os.Bundle
import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.net.InetSocketAddress
import java.net.Socket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Ink = Color(0xFF14201D)
private val Mint = Color(0xFFB8F28B)
private val Canvas = Color(0xFFF5F7F3)
private val Muted = Color(0xFF64716A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Ink,
                    onPrimary = Color.White,
                    secondary = Color(0xFF3B6B54),
                    background = Canvas,
                    surface = Color.White
                )
            ) {
                TVTidyApp()
            }
        }
    }
}

private enum class Screen(val title: String) {
    HOME("TV Tidy"),
    CONNECT("Подключение ТВ"),
    ANALYSE("Анализ телевизора"),
    RESTORE("Резервная копия"),
    ACTIVITY("Управление и журнал"),
    SETTINGS("Настройки")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TVTidyApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(screen.title, fontWeight = FontWeight.Bold)
                        if (screen == Screen.HOME) {
                            Text("Порядок на ТВ — с возможностью восстановления", style = MaterialTheme.typography.labelMedium, color = Muted)
                        }
                    }
                }
            )
        },
        containerColor = Canvas
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    onConnect = { screen = Screen.CONNECT },
                    onAnalyse = { screen = Screen.ANALYSE },
                    onRestore = { screen = Screen.RESTORE },
                    onActivity = { screen = Screen.ACTIVITY },
                    onSettings = { screen = Screen.SETTINGS }
                )
                Screen.CONNECT -> ConnectScreen(onBack = { screen = Screen.HOME })
                Screen.ANALYSE -> AnalysisScreen(onBack = { screen = Screen.HOME })
                Screen.RESTORE -> RestoreScreen(onBack = { screen = Screen.HOME })
                Screen.ACTIVITY -> ActivityScreen(onBack = { screen = Screen.HOME })
                Screen.SETTINGS -> SettingsScreen(onBack = { screen = Screen.HOME })
            }
        }
    }
}

@Composable
private fun HomeScreen(
    onConnect: () -> Unit,
    onAnalyse: () -> Unit,
    onRestore: () -> Unit,
    onActivity: () -> Unit,
    onSettings: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Ink),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(54.dp).background(Mint, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = Ink, modifier = Modifier.size(28.dp))
            }
            Text("Твой телевизор. Твои правила.", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                "Сначала проверь Android TV. Все действия должны быть понятными, обратимыми и выполняться только с твоего согласия.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFFD5DED8)
            )
            Button(onClick = onConnect, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Devices, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Подключить телевизор")
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ArrowForward, contentDescription = null)
            }
        }
    }

    SectionLabel("ВОЗМОЖНОСТИ")
    ActionCard("Анализ устройства", "Список приложений появится после завершения авторизованного ADB-подключения.", Icons.Default.Security, onAnalyse)
    ActionCard("Резервное копирование", "Профиль подключения и план восстановления.", Icons.Default.Restore, onRestore)
    ActionCard("Удалённое управление", "Диагностика сетевого ADB; команды станут доступны после авторизации.", Icons.Default.Devices, onActivity)
    ActionCard("Очистка и лаунчер", "Запланированные функции. Системные приложения не изменяются автоматически.", Icons.Default.Tune, onSettings)

    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE9F4E2))) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF2F6844))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Безопасный ознакомительный режим", fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "TV Tidy теперь отправляет начальный пакет протокола ADB и определяет ответ демона. Подпись ключом и команды оболочки пока не реализованы.",
                    color = Color(0xFF3D5A47),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun ConnectScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tv_tidy_profile", Context.MODE_PRIVATE) }
    var host by remember { mutableStateOf(prefs.getString("host", "192.168.1.140") ?: "192.168.1.140") }
    var port by remember { mutableStateOf(prefs.getString("port", "5555") ?: "5555") }
    var status by remember { mutableStateOf("Профиль загружен. Нажми «Проверить ADB» для обмена с демоном телевизора.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    PageIntro("Подключение к телевизору", "Укажи локальный IP-адрес ТВ и TCP-порт ADB. Телефон и телевизор должны быть в одной доверенной сети Wi-Fi.")
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Сетевой адрес телевизора", fontWeight = FontWeight.Bold, color = Ink)
            androidx.compose.material3.OutlinedTextField(
                value = host,
                onValueChange = { host = it.trim() },
                label = { Text("IP-адрес или имя узла ТВ") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
            )
            androidx.compose.material3.OutlinedTextField(
                value = port,
                onValueChange = { port = it.filter(Char::isDigit).take(5) },
                label = { Text("TCP-порт") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedButton(
                onClick = {
                    val targetHost = host.trim()
                    val targetPort = port.toIntOrNull()
                    if (targetHost.isBlank() || targetPort == null || targetPort !in 1..65535) {
                        status = "Укажи корректный адрес и порт (1–65535)."
                    } else {
                        prefs.edit().putString("host", targetHost).putString("port", targetPort.toString()).apply()
                        status = "Профиль телевизора сохранён на телефоне."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Сохранить профиль ТВ") }
            Button(
                onClick = {
                    val targetHost = host.trim()
                    val targetPort = port.toIntOrNull()
                    if (targetHost.isBlank() || targetPort == null || targetPort !in 1..65535) {
                        status = "Укажи корректный адрес и порт (1–65535)."
                    } else {
                        busy = true
                        status = "Выполняем начальный обмен ADB…"
                        prefs.edit().putString("host", targetHost).putString("port", targetPort.toString()).apply()
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                try {
                                    when (val result = AdbClient.connectAndListPackages(targetHost, targetPort)) {
                                        is AdbClient.Result.Connected -> {
                                            prefs.edit()
                                                .putStringSet("last_packages", result.packages.toSet())
                                                .putString("last_adb_banner", result.banner)
                                                .putLong("last_scan_time", System.currentTimeMillis())
                                                .apply()
                                            "Авторизация ADB успешна. Получено пакетов: ${result.packages.size}. Открой «Анализ телевизора», чтобы посмотреть список."
                                        }
                                        AdbClient.Result.AuthorizationTimedOut -> "Ожидание подтверждения на телевизоре завершилось. Повтори подключение и нажми «Разрешить» на экране ТВ."
                                        AdbClient.Result.AuthorizationRejected -> "Телевизор не принял ключ TV Tidy. Проверь запрос на экране ТВ и повтори подключение."
                                        AdbClient.Result.SecureTransportUnsupported -> "Телевизор запросил защищённый транспорт ADB, который пока не поддержан этой версией."
                                        is AdbClient.Result.Failed -> "ADB не завершил подключение: ${result.message}."
                                    }
                                } catch (e: java.net.ConnectException) {
                                    "Соединение отклонено: ADB не слушает этот порт. Проверь сетевую отладку и порт на ТВ."
                                } catch (e: java.net.SocketTimeoutException) {
                                    "Время ожидания истекло. Если на ТВ появилось окно разрешения, нажми «Разрешить» и попробуй снова."
                                } catch (e: Exception) {
                                    "Не удалось подключиться к ADB: ${e.localizedMessage ?: e.javaClass.simpleName}"
                                }
                            }
                            status = result
                            busy = false
                        }
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Подключаемся…" else "Проверить ADB") }
            Text(status, color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
    }
    InfoCard("Что происходит при подключении", listOf(
        "TV Tidy создаёт собственный RSA-ключ в защищённом хранилище Android; закрытый ключ не экспортируется.",
        "Если ТВ покажет запрос авторизации, нажми «Разрешить» и при желании включи «Всегда разрешать».",
        "После авторизации приложение запрашивает только список пакетов. Оно не отключает и не удаляет приложения.",
        "Не открывай ADB в публичный интернет. Используй доверенную домашнюю сеть и отключай отладку после завершения."
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun AnalysisScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tv_tidy_profile", Context.MODE_PRIVATE) }
    val packages = remember { prefs.getStringSet("last_packages", emptySet())?.toList()?.sorted().orEmpty() }
    val lastScan = prefs.getLong("last_scan_time", 0L)
    PageIntro("Анализ телевизора", "Список получен с телевизора по авторизованному ADB. На этом этапе анализ только читает данные и ничего не меняет.")
    InfoCard("Текущие сведения", listOf(
        "Устройство: iFFALCON / Android TV 11 (по предоставленным данным)",
        "Найдено пакетов: ${packages.size}",
        if (lastScan > 0L) "Последнее чтение: ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(lastScan))}" else "Последнее чтение: ещё не выполнялось",
        "Предлагаемые изменения: не применяются автоматически"
    ))
    if (packages.isNotEmpty()) {
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Пакеты телевизора", fontWeight = FontWeight.Bold, color = Ink)
                packages.take(250).forEach { packageName ->
                    Text(packageName, color = Ink, style = MaterialTheme.typography.bodySmall)
                    Divider(color = Color(0xFFE9EDF2))
                }
                if (packages.size > 250) Text("Показаны первые 250 из ${packages.size} пакетов.", color = Muted)
            }
        }
    } else {
        InfoCard("Пока нет данных", listOf("Перейди в «Подключение к телевизору» и выполни авторизованное подключение ADB."))
    }
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1D9))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Изменения не применяются", fontWeight = FontWeight.Bold)
            Text("Перед любыми будущими изменениями TV Tidy должен показать точный список действий и создать точку восстановления.")
        }
    }
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun RestoreScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tv_tidy_profile", Context.MODE_PRIVATE) }
    var message by remember { mutableStateOf("В этой сессии профиль ещё не экспортировался.") }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri == null) {
            message = "Экспорт отменён."
        } else {
            try {
                val json = JSONObject().apply {
                    put("schema", 1)
                    put("app", "TV Tidy")
                    put("appVersion", "0.5.0-alpha")
                    put("tvHost", prefs.getString("host", "192.168.1.140"))
                    put("adbPort", prefs.getString("port", "5555"))
                    put("tvModel", "iFFALCON AR2101")
                    put("androidVersion", "11")
                    put("backupType", "connection-profile-only")
                    put("createdAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date()))
                }
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(json.toString(2).toByteArray(Charsets.UTF_8))
                } ?: throw IllegalStateException("Не удалось открыть выбранный файл")
                message = "Профиль подключения экспортирован. Это не резервная копия приложений или состояния ТВ."
            } catch (e: Exception) {
                message = "Ошибка экспорта: ${e.localizedMessage ?: e.javaClass.simpleName}"
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) {
            message = "Импорт отменён."
        } else {
            try {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException("Не удалось прочитать выбранный файл")
                val json = JSONObject(raw)
                require(json.optInt("schema", -1) == 1) { "Неподдерживаемый формат профиля" }
                val importedHost = json.optString("tvHost", "").trim()
                val importedPort = json.optString("adbPort", "5555").trim()
                require(importedHost.isNotBlank()) { "В профиле не указан адрес телевизора" }
                val importedPortNumber = importedPort.toIntOrNull()
                require(importedPortNumber != null && importedPortNumber in 1..65535) { "В профиле указан неверный порт" }
                prefs.edit().putString("host", importedHost).putString("port", importedPort).apply()
                message = "Профиль импортирован. Открой «Подключение ТВ» и проверь адрес перед тестированием."
            } catch (e: Exception) {
                message = "Ошибка импорта: ${e.localizedMessage ?: e.javaClass.simpleName}"
            }
        }
    }

    PageIntro("Резервная копия и восстановление", "Сейчас можно экспортировать и импортировать профиль подключения. Для резервной копии состояния телевизора требуется авторизованный ADB, который пока не реализован.")
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Локальный профиль подключения", fontWeight = FontWeight.Bold, color = Ink)
            Text("Телевизор: ${prefs.getString("host", "192.168.1.140")}  ·  Порт: ${prefs.getString("port", "5555")}", color = Muted)
            Button(onClick = { exportLauncher.launch("tv-tidy-profile.json") }, modifier = Modifier.fillMaxWidth()) {
                Text("Экспортировать профиль в файл")
            }
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) {
                Text("Импортировать профиль из файла")
            }
            Text(message, color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
    }
    InfoCard("Что не входит в эту резервную копию", listOf(
        "Список установленных пакетов телевизора",
        "Состояние системных приложений (включены или отключены)",
        "APK-файлы приложений или системные разделы",
        "План отмены изменений на телевизоре"
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun ActivityScreen(onBack: () -> Unit) {
    PageIntro("Удалённое управление и журнал", "Команды дистанционного управления пока не включены. Здесь показаны доступные функции безопасного режима.")
    InfoCard("Доступно сейчас", listOf("Проверка TCP-подключения", "Сохранение локального профиля ТВ", "Экспорт и импорт профиля подключения"))
    InfoCard("Пока недоступно", listOf("Оболочка с авторизацией ADB", "Получение списка пакетов ТВ", "События кнопок пульта", "Включение/отключение пакетов и проверенная отмена"))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit) {
    PageIntro("Настройки", "Настройки TV Tidy с приоритетом конфиденциальности.")
    InfoCard("Текущие настройки по умолчанию", listOf(
        "Учётная запись не требуется",
        "Сбор аналитики не настроен",
        "Список приложений не отправляется в облако",
        "Профиль подключения хранится локально на телефоне",
        "Системные команды не включены",
        "Экспорт содержит только профиль подключения, а не состояние системы ТВ"
    ))
    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Назад на главную") }
}

@Composable
private fun PageIntro(title: String, description: String) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
    Text(description, style = MaterialTheme.typography.bodyLarge, color = Muted)
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = Muted, fontWeight = FontWeight.Bold)
}

@Composable
private fun ActionCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(Modifier.size(44.dp).background(Color(0xFFEAF1E7), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Ink)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.Bold, color = Ink)
                Text(description, style = MaterialTheme.typography.bodyMedium, color = Muted)
            }
            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Muted)
        }
    }
}

@Composable
private fun InfoCard(title: String, lines: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Ink)
            lines.forEach { line ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.padding(top = 7.dp).size(6.dp).background(Mint, CircleShape))
                    Text(line, color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
