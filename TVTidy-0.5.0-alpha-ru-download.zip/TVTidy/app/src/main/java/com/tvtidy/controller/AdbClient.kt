package com.tvtidy.controller

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.DataInputStream
import java.io.DataOutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.security.spec.AlgorithmParameterSpec

/** Minimal ADB TCP client: authenticates this app's persistent RSA key and runs a read-only package query. */
internal object AdbClient {
    private const val ADB_VERSION = 0x01000000
    private const val ADB_MAX_DATA = 4096
    private const val CMD_CNXN = 0x4e584e43 // CNXN
    private const val CMD_AUTH = 0x48545541 // AUTH
    private const val CMD_OPEN = 0x4e45504f // OPEN
    private const val CMD_OKAY = 0x59414b4f // OKAY
    private const val CMD_WRTE = 0x45545257 // WRTE
    private const val CMD_CLSE = 0x45534c43 // CLSE
    private const val AUTH_TOKEN = 1
    private const val AUTH_SIGNATURE = 2
    private const val AUTH_PUBLIC_KEY = 3
    private const val KEY_ALIAS = "tvtidy_adb_rsa"

    sealed interface Result {
        data class Connected(val banner: String, val packages: List<String>) : Result
        data object AuthorizationTimedOut : Result
        data object AuthorizationRejected : Result
        data object SecureTransportUnsupported : Result
        data class Failed(val message: String) : Result
    }

    fun connectAndListPackages(host: String, port: Int): Result {
        val keyPair = loadOrCreateKeyPair()
        Socket().use { socket ->
            socket.connect(InetSocketAddress(host, port), 5000)
            // The TV may wait for the user to approve the public key on its screen.
            socket.soTimeout = 60_000
            val input = DataInputStream(socket.getInputStream())
            val output = DataOutputStream(socket.getOutputStream())
            val hello = "host::features=shell_v2,cmd,stat_v2,ls_v2\u0000".toByteArray(Charsets.UTF_8)
            writePacket(output, CMD_CNXN, ADB_VERSION, ADB_MAX_DATA, hello)

            var signedToken = false
            var publicKeySent = false
            var banner = "ADB"
            var authorized = false
            while (!authorized) {
                val packet = try {
                    readPacket(input)
                } catch (_: java.net.SocketTimeoutException) {
                    return Result.AuthorizationTimedOut
                } ?: return Result.Failed("Телевизор закрыл соединение")
                when (packet.command) {
                    CMD_AUTH -> {
                        if (packet.arg0 != AUTH_TOKEN) continue
                        if (!signedToken) {
                            val signer = Signature.getInstance("SHA1withRSA")
                            signer.initSign(keyPair.private)
                            signer.update(packet.data)
                            writePacket(output, CMD_AUTH, AUTH_SIGNATURE, 0, signer.sign())
                            signedToken = true
                        } else if (!publicKeySent) {
                            val adbPublicKey = encodeAdbPublicKey(keyPair.public as RSAPublicKey)
                            val payload = (Base64.encodeToString(adbPublicKey, Base64.NO_WRAP) + " tvtidy@android\u0000")
                                .toByteArray(Charsets.US_ASCII)
                            writePacket(output, CMD_AUTH, AUTH_PUBLIC_KEY, 0, payload)
                            publicKeySent = true
                        } else {
                            return Result.AuthorizationRejected
                        }
                    }
                    CMD_CNXN -> {
                        banner = packet.data.toString(Charsets.UTF_8).trimEnd('\u0000')
                        authorized = true
                    }
                    0x534c5453 -> return Result.SecureTransportUnsupported // STLS
                    else -> return Result.Failed("Неожиданный пакет ADB: 0x${packet.command.toUInt().toString(16)}")
                }
            }

            val outputText = runShellCommand(input, output, "shell:pm list packages -f\u0000")
            val packages = outputText.lineSequence()
                .map { it.trim() }
                .filter { it.startsWith("package:") }
                .mapNotNull { line -> line.substringAfter("package:").substringAfter('=', "").takeIf { it.isNotBlank() } }
                .distinct()
                .sorted()
                .toList()
            return Result.Connected(banner.ifBlank { "ADB подключён" }, packages)
        }
    }

    private data class Packet(val command: Int, val arg0: Int, val arg1: Int, val data: ByteArray)

    private fun readPacket(input: DataInputStream): Packet? {
        val header = ByteArray(24)
        try { input.readFully(header) } catch (_: java.io.EOFException) { return null }
        val b = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        val command = b.int
        val arg0 = b.int
        val arg1 = b.int
        val length = b.int
        val checksum = b.int
        val magic = b.int
        if (magic != command.inv()) throw java.io.IOException("Неверная контрольная сигнатура ADB")
        if (length < 0 || length > 1024 * 1024) throw java.io.IOException("Некорректный размер пакета ADB")
        val data = ByteArray(length)
        if (length > 0) input.readFully(data)
        val actual = data.fold(0L) { sum, byte -> (sum + (byte.toInt() and 0xff)) and 0xffffffffL }.toInt()
        if (actual != checksum) throw java.io.IOException("Ошибка контрольной суммы ADB")
        return Packet(command, arg0, arg1, data)
    }

    private fun writePacket(out: DataOutputStream, command: Int, arg0: Int, arg1: Int, data: ByteArray) {
        val checksum = data.fold(0L) { sum, byte -> (sum + (byte.toInt() and 0xff)) and 0xffffffffL }.toInt()
        val header = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(command).putInt(arg0).putInt(arg1).putInt(data.size).putInt(checksum).putInt(command.inv()).array()
        out.write(header)
        if (data.isNotEmpty()) out.write(data)
        out.flush()
    }

    private fun loadOrCreateKeyPair(): java.security.KeyPair {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!store.containsAlias(KEY_ALIAS)) {
            val generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore")
            val spec: AlgorithmParameterSpec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_SIGN
            ).setKeySize(2048)
                .setDigests(KeyProperties.DIGEST_SHA1, KeyProperties.DIGEST_SHA256)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                .setUserAuthenticationRequired(false)
                .build()
            generator.initialize(spec)
            generator.generateKeyPair()
        }
        val publicKey = store.getCertificate(KEY_ALIAS)?.publicKey
            ?: throw java.security.GeneralSecurityException("Не найден открытый ADB-ключ")
        val privateKey = store.getKey(KEY_ALIAS, null) as? java.security.PrivateKey
            ?: throw java.security.GeneralSecurityException("Не найден закрытый ADB-ключ")
        return java.security.KeyPair(publicKey, privateKey)
    }

    /** Serializes the RSA public key using the 524-byte structure expected by adb's AUTH protocol. */
    private fun encodeAdbPublicKey(key: RSAPublicKey): ByteArray {
        val modulus = key.modulus
        val modulusLittle = toLittleEndian(modulus, 256)
        val two32 = BigInteger.ONE.shiftLeft(32)
        val lowWord = BigInteger(1, modulusLittle.copyOfRange(0, 4).reversedArray())
        val n0inv = two32.subtract(lowWord.modInverse(two32)).mod(two32).toLong().toInt()
        val rr = BigInteger.ONE.shiftLeft(4096).mod(modulus)
        val rrLittle = toLittleEndian(rr, 256)
        val buffer = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        buffer.putInt(64)
        buffer.putInt(n0inv)
        buffer.put(modulusLittle)
        buffer.put(rrLittle)
        buffer.putInt(key.publicExponent.toInt())
        return buffer.array()
    }

    private fun toLittleEndian(value: BigInteger, size: Int): ByteArray {
        var big = value.toByteArray()
        if (big.size > 1 && big[0] == 0.toByte()) big = big.copyOfRange(1, big.size)
        if (big.size > size) big = big.copyOfRange(big.size - size, big.size)
        val result = ByteArray(size)
        for (i in big.indices) result[i] = big[big.lastIndex - i]
        return result
    }

    private fun runShellCommand(input: DataInputStream, output: DataOutputStream, service: String): String {
        val localId = 1
        writePacket(output, CMD_OPEN, localId, 0, service.toByteArray(Charsets.UTF_8))
        var remoteId = -1
        val result = StringBuilder()
        var packets = 0
        while (packets++ < 10000) {
            val packet = readPacket(input) ?: throw java.io.IOException("Соединение закрыто во время команды")
            when (packet.command) {
                CMD_OKAY -> { remoteId = packet.arg0 }
                CMD_WRTE -> {
                    if (remoteId < 0) remoteId = packet.arg0
                    result.append(packet.data.toString(Charsets.UTF_8))
                    writePacket(output, CMD_OKAY, localId, packet.arg0, byteArrayOf())
                }
                CMD_CLSE -> {
                    if (remoteId >= 0) writePacket(output, CMD_CLSE, localId, packet.arg0, byteArrayOf())
                    return result.toString()
                }
                else -> throw java.io.IOException("Неожиданный пакет во время чтения списка приложений")
            }
        }
        throw java.io.IOException("Превышен лимит ответа от телевизора")
    }
}
